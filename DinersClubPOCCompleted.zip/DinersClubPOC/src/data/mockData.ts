export type Lounge = {
  id: string;
  name: string;
  airport: string;
  terminal: string;
  rating: number;
  reviewCount: number;
  isOpen: boolean;
  isNew: boolean;
  coordinates: { 
    latitude: number; 
    longitude: number; 
  };
  amenities: string[];
  accessInstructions: string;
  fastTrackAvailable: boolean;
  fastTrackCount: number;
  image: string;
  hours: string;
  // --- New Keys Added Below ---
  additionalInfo: string;
  pricing: {
    memberFee: string;
    guestFee: string;
  };
  entryConditions: string;
};

export const lounges: Lounge[] = [
  {
    id: '1',
    name: 'The Club LIM (International)',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'International Pier',
    rating: 4,
    reviewCount: 1,
    isOpen: true,
    isNew: false,
    coordinates: { latitude: -12.0219, longitude: -77.1143 },
    amenities: ['Air Conditioning', 'Alcoholic Beverages', 'Conference Facilities', 'Disabled Access', 'Flight Info Monitors', 'Newspapers & Magazines', 'Non-Smoking', 'Food & Drinks', 'Shower Facilities', 'Television'],
    accessInstructions: 'Airside – pass through the main Security Checkpoint and walk right while following the signs to "Airport Lounges". Take the escalator to the Mezzanine level and walk through the corridor to find the lounge. Available to International flights only.',
    fastTrackAvailable: true,
    fastTrackCount: 5,
    image: 'https://images.unsplash.com/photo-1559329007-40df8a9345d8?w=800',
    hours: '24 hours daily',
    additionalInfo: 'Digital newspapers/magazines available only. Local telephone calls are subject to payment.',
    pricing: { memberFee: 'Complimentary', guestFee: 'US$32 per person' },
    entryConditions: 'Maximum 3 hour stay. Children under 2 years are admitted free. All children must be accompanied by an adult.'
  },
  {
    id: '2',
    name: 'La Bonbonniere',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'International Pier',
    rating: 4,
    reviewCount: 8,
    isOpen: true,
    isNew: false,
    coordinates: { latitude: -12.022, longitude: -77.1145 },
    amenities: ['Air Conditioning', 'Alcoholic Beverages', 'Food & Drinks', 'Non-Smoking', 'Television', 'Newspapers & Magazines'],
    accessInstructions: 'Airside – proceed past security and follow signs to the International Pier.',
    fastTrackAvailable: false,
    fastTrackCount: 0,
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800',
    hours: '06:00 - 23:00 daily',
    additionalInfo: 'A la carte menu available at additional cost.',
    pricing: { memberFee: 'US$27 per visit', guestFee: 'US$27 per person' },
    entryConditions: 'Cardholders must present a valid boarding pass for same-day travel.'
  },
  {
    id: '3',
    name: 'Copper Bar',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'International Pier',
    rating: 3,
    reviewCount: 5,
    isOpen: true,
    isNew: true,
    coordinates: { latitude: -12.0221, longitude: -77.1147 },
    amenities: ['Air Conditioning', 'Alcoholic Beverages', 'Food & Drinks', 'Non-Smoking'],
    accessInstructions: 'Airside – located on the main terminal floor near Gate 5.',
    fastTrackAvailable: false,
    fastTrackCount: 0,
    image: 'https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=800',
    hours: '08:00 - 02:00 daily',
    additionalInfo: 'Premium spirits and wine are subject to payment.',
    pricing: { memberFee: 'Included', guestFee: 'US$30 per person' },
    entryConditions: 'Smart casual dress code at all times.'
  },
  {
    id: '4',
    name: 'Sumaq VIP Lounge',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'International Pier',
    rating: 5,
    reviewCount: 124,
    isOpen: true,
    isNew: false,
    coordinates: { latitude: -12.0225, longitude: -77.1150 },
    amenities: ['Air Conditioning', 'Showers', 'Alcoholic Beverages', 'Digital Magazines', 'Business Center', 'WiFi', 'Private Rooms'],
    accessInstructions: 'Airside - After Passport Control, turn left. The lounge is located near Gate 17 on the second floor.',
    fastTrackAvailable: true,
    fastTrackCount: 2,
    image: 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?w=800',
    hours: '24 hours daily',
    additionalInfo: 'Private relaxation rooms are available upon request and subject to availability.',
    pricing: { memberFee: 'Complimentary', guestFee: 'US$35 per person' },
    entryConditions: 'Access may be restricted due to space constraints.'
  },
  {
    id: '5',
    name: 'Hanaq VIP Lounge',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'Domestic Terminal',
    rating: 4,
    reviewCount: 45,
    isOpen: true,
    isNew: false,
    coordinates: { latitude: -12.0230, longitude: -77.1160 },
    amenities: ['Childrens Area', 'Buffet', 'Flight Monitors', 'Television', 'WiFi'],
    accessInstructions: 'Airside - Domestic Departures. After security, the lounge is located on the second floor, opposite Gate 12.',
    fastTrackAvailable: false,
    fastTrackCount: 0,
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800',
    hours: '24 hours daily',
    additionalInfo: 'Children under 5 years are admitted free.',
    pricing: { memberFee: 'Complimentary', guestFee: 'US$25 per person' },
    entryConditions: 'Available for domestic flight passengers only.'
  },
  {
    id: '6',
    name: 'The VIP Club (Domestic)',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'Domestic Terminal',
    rating: 4,
    reviewCount: 12,
    isOpen: false,
    isNew: true,
    coordinates: { latitude: -12.0210, longitude: -77.1130 },
    amenities: ['Air Conditioning', 'Non-Smoking', 'Refreshments', 'WiFi'],
    accessInstructions: 'Landside - Located before Security Checks, near the main check-in counters on the 2nd level.',
    fastTrackAvailable: true,
    fastTrackCount: 1,
    image: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?q=80&w=800&auto=format&fit=crop',
    hours: '05:00 - 22:00 daily',
    additionalInfo: 'Alcoholic beverages are not served.',
    pricing: { memberFee: 'US$20 per visit', guestFee: 'US$20 per person' },
    entryConditions: 'Maximum stay of 2 hours applies.'
  },
  {
    id: '7',
    name: 'Bleriot Bar & Lounge',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'International Pier',
    rating: 3,
    reviewCount: 22,
    isOpen: true,
    isNew: false,
    coordinates: { latitude: -12.0235, longitude: -77.1170 },
    amenities: ['Premium Food', 'Spirits', 'Newspapers', 'Television'],
    accessInstructions: 'Airside - International Departures. Located in the shopping area near Gate 24.',
    fastTrackAvailable: false,
    fastTrackCount: 0,
    image: 'https://images.unsplash.com/photo-1565031491910-e57fac031c41?w=800',
    hours: '08:00 - 00:00 daily',
    additionalInfo: 'Smoking area available outside the lounge entrance.',
    pricing: { memberFee: 'US$30 per visit', guestFee: 'US$35 per person' },
    entryConditions: 'Boarding pass must be presented upon entry.'
  },
  {
    id: '8',
    name: 'Sleepover Rest Area',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'International Pier',
    rating: 4,
    reviewCount: 56,
    isOpen: true,
    isNew: false,
    coordinates: { latitude: -12.0240, longitude: -77.1180 },
    amenities: ['Quiet Zone', 'Showers', 'Bedding', 'WiFi'],
    accessInstructions: 'Airside - International Departures. Follow signs for "Rest Zones" near the transit hotel.',
    fastTrackAvailable: true,
    fastTrackCount: 8,
    image: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?w=800',
    hours: '24 hours daily',
    additionalInfo: 'Sleeping pods available for 4-hour blocks.',
    pricing: { memberFee: 'US$40 per visit', guestFee: 'US$50 per person' },
    entryConditions: 'Quiet zone rules strictly enforced. No phone calls permitted.'
  }
];

export const featureTiles = [
  { id: '1', label: 'Airport Services', icon: 'airplane', image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=400' },
  { id: '2', label: 'Merchant Offers', icon: 'pricetag', image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400' },
  { id: '3', label: 'ATM Finder', icon: 'cash', image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400' },
  { id: '4', label: 'Travel Guides', icon: 'map', image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=400' },
  { id: '5', label: 'Account Access', icon: 'person-circle', image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400' },
  { id: '6', label: 'Map View', icon: 'globe', image: 'https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400' },
  { id: '7', label: 'Currency Converter', icon: 'swap-horizontal', image: 'https://images.unsplash.com/photo-1580519542036-c47de6196ba5?w=400' },
  { id: '8', label: 'Tip Calculator', icon: 'calculator', image: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=400' },
  { id: '9', label: 'Card Assistance', icon: 'card', image: 'https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=400' },
  { id: '10', label: 'Benefits', icon: 'gift', image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=400' },
];
