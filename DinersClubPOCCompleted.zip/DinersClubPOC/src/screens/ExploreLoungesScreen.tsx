import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  FlatList,
  StyleSheet,
  StatusBar,
  TextInput,
  TouchableOpacity,
  Image,
  ImageBackground,
  Dimensions,
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../navigation/AppNavigator';
import Header from '../components/Header';
import CategoryCard from '../components/CategoryCard';
import LoungeCard from '../components/LoungeCard';
import { lounges } from '../data/mockData';
import { Feather, MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { Entypo } from '@expo/vector-icons';
import { ScreenWrapper } from '../components/ScreenWrapper';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'ExploreLounges'>;
  route: RouteProp<RootStackParamList, 'ExploreLounges'>;
};

const { width } = Dimensions.get('window');

const LOUNGE_LIST = [
  {
    id: '1',
    title: 'The Club LIM (International)',
    location: 'Lima Jorge Chavez Intl, Lima, Peru',
    terminal: 'International Pier',
    rating: 4,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?w=600',
  },
  {
    id: '2',
    title: 'La Bonbonniere',
    location: 'Lima Jorge Chavez Intl, Lima, Peru',
    terminal: 'International Pier',
    rating: 0,
    isOpen: false,
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600',
  },
  {
    id: '3',
    title: 'Copper Bar',
    location: 'Lima Jorge Chavez Intl, Lima, Peru',
    terminal: 'International Pier',
    rating: 4.5,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=600',
  },{
    id: '4',
    title: 'Sleepover',
    location: 'Lima Jorge Chavez Intl, Lima, Peru',
    terminal: 'International Pier',
    rating: 0,
    isOpen: true, // Matches the "OPEN NOW" badge in the fourth card of the spec
    image: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?w=800', // Luxury nap/rest area
  },
  {
    id: '5',
    title: 'Hanaq VIP Lounge',
    location: 'Lima Jorge Chavez Intl, Lima, Peru',
    terminal: 'Domestic Terminal',
    rating: 4.2,
    isOpen: true,
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800', // Modern airport interior
  },
  {
    id: '6',
    title: 'Sumaq VIP Lounge',
    location: 'Lima Jorge Chavez Intl, Lima, Peru',
    terminal: 'International Pier',
    rating: 4.8,
    isOpen: false,
    image: 'https://images.unsplash.com/photo-1565031491910-e57fac031c41?w=800', // Elegant lounge seating
  }
];

const AMENITIES_DATA = [
  {
    id: 'dining',
    title: 'DINING',
    subTitle: 'Browse all lounges\nwith dining options.',
    color: '#041e42',
imageUrl: 'https://images.unsplash.com/photo-1496116218417-1a781b1c416c?q=80&w=800&auto=format&fit=crop',
    arrowColor: '#00a3e0'
  },{
    id: 'spas',
    title: 'SPAS',
    subTitle: 'Browse lounges\nwith spa services.',
    color: '#009ca6', // Teal from spec
imageUrl: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?q=80&w=800&auto=format&fit=crop',  },
  {
    id: 'airport_services',
    title: 'AIRPORT SERVICES',
    subTitle: 'Fast track and\nconcierge help.',
    color: '#041e42', // Navy from spec
imageUrl: 'https://images.unsplash.com/photo-1520437358207-323b43b50729?q=80&w=800&auto=format&fit=crop',    arrowColor: '#00a3e0'
  },
  {
    id: 'offers',
    title: 'MERCHANT OFFERS',
    subTitle: 'Exclusive duty-free\nand retail deals.',
    color: '#009ca6', // Teal from spec
imageUrl: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=800&auto=format&fit=crop',    arrowColor: '#ffffff'
  },
  {
    id: 'atm',
    title: 'ATM FINDER',
    subTitle: 'Locate the nearest\ncash machines.',
    color: '#041e42', // Navy from spec
imageUrl: 'https://images.unsplash.com/photo-1550565118-3a14e8d0386f?q=80&w=800&auto=format&fit=crop',    arrowColor: '#00a3e0'
  },
  {
    id: 'guides',
    title: 'TRAVEL GUIDES',
    subTitle: 'Explore your\ndestination expertly.',
    color: '#009ca6', // Teal from spec
    imageUrl: 'https://images.unsplash.com/photo-1527631746610-bca00a040d60?q=80&w=500&auto=format&fit=crop',
    arrowColor: '#ffffff'
  }
];

//const LoungesScreen = () => {
 export default function LoungesScreen({ navigation }: Props) {

  const [location, setLocation] = useState(''); // Initial value from spec

  return (
    // <SafeAreaView style={styles.container}>
      <ScreenWrapper showBack={true} backLabel="HOME">


      <ScrollView showsVerticalScrollIndicator={false}>
              <Text style={styles.welcomeText}>Lounges</Text>

        {/* PAGE TITLE & SEARCH */}
        {/* <View style={styles.headerSection}>
          <Text style={styles.pageTitle}>Lounges</Text>
          <View style={styles.locationRow}>
            <Text style={styles.locationText}>Lima, Peru</Text>
          </View> */}
          
          {/* <View style={styles.searchBar}>
            <TextInput 
              placeholder="EXPLORE AIRPORT LOUNGE BENEFITS" 
              placeholderTextColor="#97999b"
              style={styles.searchInput}
            />
            <TouchableOpacity style={styles.searchIconBox}>
              <Feather name="search" size={20} color="white" />
            </TouchableOpacity>
          </View> */}
        {/* </View> */}

        <View style={styles.shadowWrapper}>
      <View style={styles.mainContainer}>
        
        {/* LEFT SECTION: ACTIVE TEXT INPUT */}
        <View style={styles.inputSection}>
          <TextInput
            style={styles.textInput}
            value={location}
            onChangeText={setLocation}
            placeholder="Search Location"
            placeholderTextColor="#97999b"
            selectionColor="#00a3e0" // Brand blue cursor
          />
        </View>

        {/* RIGHT SECTION: DIVIDER & BUTTON */}
        <View style={styles.actionSection}>
          <View style={styles.verticalDivider} />
          
          <TouchableOpacity 
            activeOpacity={0.7} 
            style={styles.searchCircle}
          >
            <Feather name="search" size={22} color="white" />
          </TouchableOpacity>
        </View>
        
      </View>
    </View>

        <Text style={styles.headText}>EXPLORE AIRPORT LOUNGE BENEFITS</Text>

        {/* CATEGORY TILES (Horizontal) */}

        <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false} 
        contentContainerStyle={styles.scrollContent}
      >
        {AMENITIES_DATA.map((item) => (
          <TouchableOpacity key={item.id} style={styles.gridItems}>
                         <ImageBackground 
                          source={{ uri: item.imageUrl }} 
                          style={styles.gridImage} 
                          imageStyle={{ borderRadius: 30 }}
                         >
                          <View style={styles.gridTitleContainer}>
                            <Text style={styles.gridTitle} numberOfLines={1}>{item.title}</Text>
                            <Text style={styles.gridSubTitle} numberOfLines={2}>{item.subTitle}</Text>

                          </View>
                        </ImageBackground>
                      </TouchableOpacity>
          // <TouchableOpacity key={item.id} activeOpacity={0.9}>
          //   <View style={[styles.tileWrapper, { backgroundColor: item.color }]}>
          //     <ImageBackground
          //       source={{ uri: item.imageUrl }}
          //       style={styles.catTile}
          //       imageStyle={styles.tileImageStyle}
          //     >
          //       {/* Content Overlay */}
          //       <View style={styles.contentOverlay}>
          //         <View style={styles.textWrapper}>
          //           <Text style={styles.catTitle}>{item.title}</Text>
          //           <Text style={styles.catSub}>{item.subTitle}</Text>
          //         </View>

          //         <View style={styles.arrowContainer}>
          //           <Feather name="arrow-right" size={24} color={item.arrowColor} />
          //         </View>
          //       </View>
          //     </ImageBackground>
          //   </View>
          // </TouchableOpacity>
        ))}
      </ScrollView>


        {/* <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
          <TouchableOpacity style={[styles.catTile, { backgroundColor: '#041e42' }]}>
            <Text style={styles.catTitle}>DINING</Text>
            <Text style={styles.catSub}>Browse all lounges with dining options.</Text>
            <Feather name="arrow-right" size={20} color="#00a3e0" style={styles.catArrow} />
          </TouchableOpacity>

          <TouchableOpacity style={[styles.catTile, { backgroundColor: '#009ca6' }]}>
            <Text style={styles.catTitle}>SPAS</Text>
            <Text style={styles.catSub}>Browse lounges with spa services.</Text>
            <Feather name="arrow-right" size={20} color="white" style={styles.catArrow} />
          </TouchableOpacity>
        </ScrollView> */}

        {/* LOUNGE LIST SECTION */}

        <Text style={styles.headText}>EXPLORE AIRPORT LOUNGES NEAR YOU</Text>


        {lounges.map((lounge) => (
          <TouchableOpacity key={lounge.id} style={styles.loungeCard} onPress={() => navigation.navigate('LoungeDetail', { lounge })}>
            <View style={styles.imageWrapper}>
              <Image source={{ uri: lounge.image }} style={styles.loungeImg} />
              {lounge.isOpen && (
                <View style={styles.openBadge}>
                  <Text style={styles.openText}>OPEN NOW</Text>
                </View>
              )}
              <View style={styles.blueDotMenu}>
                <Entypo name="dots-three-horizontal" size={14} color="white" />
              </View>
            </View>

            <View style={styles.infoSection}>
              <Text style={styles.loungeTitle}>{lounge.name}</Text>
              <View style={styles.ratingRow}>
                {[1, 2, 3, 4, 5].map((s) => (
                  <Ionicons key={s} name="ellipse" size={8} color={s <= lounge.rating ? "#004c97" : "#d1d1d1"} style={{ marginRight: 2 }} />
                ))}
                <Text style={styles.ratingText}>({lounge.rating} rating)</Text>
              </View>
              
              <Text style={styles.locationDetail}>{lounge.airport}</Text>
              <Text style={styles.terminalText}>{lounge.terminal}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </ScreenWrapper>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f7f7f7' },
  navBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, height: 60 },
  backBtn: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#00a3e0', paddingRight: 12, borderRadius: 20 },
  backText: { color: 'white', fontWeight: 'bold', fontSize: 12, marginLeft: -4 },
  
  headerSection: { paddingHorizontal: 24, marginTop: 10 },
  pageTitle: { fontSize: 38, fontWeight: '700', color: '#004c97' },
  locationRow: { marginTop: 4 },
  locationText: { color: '#97999b', fontSize: 18 },
  
  searchBar: { flexDirection: 'row', backgroundColor: 'white', borderRadius: 8, marginTop: 20, alignItems: 'center', borderWidth: 1, borderColor: '#e1e1e1' },
  searchInput: { flex: 1, paddingHorizontal: 15, height: 45, fontSize: 12, letterSpacing: 0.5 },
  searchIconBox: { backgroundColor: '#00a3e0', width: 45, height: 45, justifyContent: 'center', alignItems: 'center', borderTopRightRadius: 7, borderBottomRightRadius: 7 },

  categoryScroll: { marginTop: 20, paddingLeft: 24 },
  // catTile: { width: 180, height: 110, borderRadius: 12, padding: 15, marginRight: 15 },
  // catTitle: { color: 'white', fontSize: 18, fontWeight: 'bold' },
  // catSub: { color: 'white', fontSize: 11, marginTop: 5, opacity: 0.9 },
  catArrow: { alignSelf: 'flex-end', marginTop: 'auto' },

  listHeader: { paddingHorizontal: 24, marginTop: 30 },
  listLabel: { fontSize: 11, color: '#97999b', fontWeight: '600' },
  lineDivider: { height: 1, backgroundColor: '#009ca6', marginTop: 8, width: '100%' },

  loungeCard: { backgroundColor: 'white', marginHorizontal: 10, marginTop: 15, borderRadius: 30, overflow: 'hidden', elevation: 2, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 },
  imageWrapper: { height: 160 },
  loungeImg: { width: '100%', height: '100%' },
  openBadge: { position: 'absolute', top: 12, left: 12, backgroundColor: '#00a3e0', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 4 },
  openText: { color: 'white', fontSize: 10, fontWeight: 'bold' },
  blueDotMenu: { position: 'absolute', top: 12, right: 12, backgroundColor: '#00a3e0', width: 24, height: 24, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  
  infoSection: { padding: 15 },
  loungeTitle: { fontSize: 16, fontWeight: 'bold', color: '#004c97' },
  ratingRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  ratingText: { fontSize: 10, color: '#97999b', marginLeft: 5 },
  locationDetail: { fontSize: 12, color: '#4a4a4a', marginTop: 8 },
  terminalText: { fontSize: 12, color: '#97999b' },

  sectionContainer: {
    marginTop: 24,
  },
  scrollContent: {
    paddingBottom: 20
    
  },
  tileWrapper: {
    width: width * 0.46, // Matches exact grid proportions
    height: 113,         // Exact DP height from spec
    borderRadius: 12,
    marginRight: 16,
    overflow: 'hidden',
  },
  catTile: {
    flex: 1,
    padding: 14,
  },
  tileImageStyle: {
    opacity: 0.45,       // Blends Unsplash image with the brand color
    resizeMode: 'cover',
  },
  contentOverlay: {
    flex: 1,
    justifyContent: 'space-between',
  },
  textWrapper: {
    flex: 1,
  },
  catTitle: {
    color: 'white',
    fontSize: 22,
    fontWeight: '800', // Gotham Bold style
    letterSpacing: 0.5,
  },
  catSub: {
    color: 'white',
    fontSize: 11,
    lineHeight: 14,
    marginTop: 2,
    fontWeight: '500',
  },
  arrowContainer: {
    alignSelf: 'flex-end',
    // Exact positioning from bottom-right markers
    marginBottom: -2,
    marginRight: -2,
  },
  gridItems: { width: (width / 1.4), height: 490, margin: 8 },
  gridImage: { flex: 1, justifyContent: 'flex-end', height: '80%', width: '100%' },
  iconBadge: { position: 'absolute', top: 8, right: 8, backgroundColor: '#00a3e0', borderRadius: 12, padding: 4, elevation: 3 },
  gridTitleContainer: { backgroundColor: '#041e42', height: 113, borderBottomLeftRadius: 30, borderBottomRightRadius: 30, justifyContent: 'center', alignItems: 'flex-start', paddingHorizontal: 5 },
  gridTitle: { color: 'white', fontSize: 24, fontWeight: '500', textAlign: 'left', paddingHorizontal: 27, marginTop: 24, letterSpacing: 3, fontFamily: 'Gotham-Bold' },
  gridSubTitle: { color: 'white', fontSize: 14, fontWeight: '500', textAlign: 'left', paddingHorizontal: 27, marginTop: 5, marginBottom: 18, letterSpacing: 1.2 },

  headText: { flex: 1, paddingHorizontal: 15, height: 25, fontSize: 12, letterSpacing: 0.9 },


  shadowWrapper: {
    paddingHorizontal: 10, // Matches the '24' DP margin in spec
    paddingBottom: 20, // Removes bottom padding to align with spec
    // Premium soft shadow
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.12,
        shadowRadius: 10,
  },
  mainContainer: {
    backgroundColor: '#ffffff',
    height: 58, // Fixed height from spec
    borderRadius: 30, // Half of height for perfect pill
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 20, // Padding before text starts
    paddingRight: 8,  // Tight padding for the circular button
  },
  inputSection: {
    flex: 1,
    height: '100%',
    justifyContent: 'center',
  },
  textInput: {
    fontSize: 18,
    color: '#97999b', // Hex code from spec
    fontWeight: '400',
    letterSpacing: 0.2, // Subtle Gotham-style spacing
    paddingVertical: 0, // Prevents Android default padding issues
  },
  actionSection: {
    flexDirection: 'row',
    alignItems: 'center',
    height: '100%',
  },
  verticalDivider: {
    width: 1.5,
    height: 28, // Matches the '54' vs '28' proportional height in spec
    backgroundColor: '#efefef',
    marginHorizontal: 10,
  },
  searchCircle: {
    backgroundColor: '#00a3e0', // Brand blue
    width: 38, // Matches '46px' marker
    height: 38,
    borderRadius: 38,
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcomeText: { fontSize: 36, fontWeight: '700', color: '#004c97', lineHeight: 40, paddingHorizontal: 10, marginBottom: 12 },

});

// export default LoungesScreen;
// export default function ExploreLoungesScreen({ navigation }: Props) {
//   return (
//     <SafeAreaView style={styles.container}>
    
//     <View style={styles.root}>
//       <StatusBar barStyle="light-content" backgroundColor="#002868" />
//       <Header
//         onBack={() => navigation.goBack()}
//         backLabel="HOME"
//         showSearch
//         onSearch={() => {}}
//       />

//       <ScrollView showsVerticalScrollIndicator={false}>
//         {/* Title */}
//         <View style={styles.titleBlock}>
//           <Text style={styles.title}>Lounges</Text>
//           <Text style={styles.location}>Lima, Peru</Text>
//         </View>

//         {/* Category Section */}
//         <View style={styles.sectionHeader}>
//           <Text style={styles.sectionTitle}>EXPLORE AIRPORT LOUNGE BENEFITS</Text>
//         </View>
//         <View style={styles.categoryRow}>
//           <CategoryCard
//             title="DINING"
//             subtitle="Browse all lounges with dining options"
//             image="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600"
//             onPress={() => {}}
//           />
//           <CategoryCard
//             title="SPA"
//             subtitle="Browse all lounges with spa facilities"
//             image="https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=600"
//             onPress={() => {}}
//           />
//         </View>

//         {/* Lounge List Section */}
//         <View style={styles.sectionHeader}>
//           <Text style={styles.sectionTitle}>EXPLORE AIRPORT LOUNGES NEAR YOU</Text>
//         </View>

//         {lounges.map((lounge) => (
//           <LoungeCard
//             key={lounge.id}
//             lounge={lounge}
//             onPress={() => navigation.navigate('LoungeDetail', { lounge })}
//           />
//         ))}

//         <View style={{ height: 30 }} />
//       </ScrollView>
//     </View>
//     </SafeAreaView>
//   );
// }

// const styles = StyleSheet.create({
//   root: {
//     flex: 1,
//     backgroundColor: '#F0F4F8',
//   },
//   titleBlock: {
//     backgroundColor: '#fff',
//     paddingHorizontal: 20,
//     paddingVertical: 16,
//     borderBottomWidth: 1,
//     borderBottomColor: '#e0e0e0',
//   },
//   title: {
//     fontSize: 26,
//     fontWeight: '800',
//     color: '#002868',
//   },
//   location: {
//     fontSize: 13,
//     color: '#666',
//     marginTop: 2,
//   },
//   sectionHeader: {
//     paddingHorizontal: 16,
//     paddingTop: 20,
//     paddingBottom: 10,
//   },
//   sectionTitle: {
//     fontSize: 11,
//     fontWeight: '800',
//     color: '#002868',
//     letterSpacing: 0.8,
//     textTransform: 'uppercase',
//   },
//   categoryRow: {
//     flexDirection: 'row',
//     paddingHorizontal: 12,
//   },
//   container: { flex: 1, backgroundColor: '#f7f7f7' },

// });
