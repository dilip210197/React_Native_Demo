import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
  Linking,
  StatusBar,
  Dimensions,
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { Feather, MaterialIcons, Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import AmenityItem from '../components/AmenityItem';
import { ScreenWrapper } from '../components/ScreenWrapper';


const { width } = Dimensions.get('window');

// Custom Star Rating to match the Spec (Small dots/stars)
function StarRating({ rating }: { rating: number }) {
  return (
    <View style={styles.ratingStars}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Ionicons
          key={i}
          name={i <= rating ? "ellipse" : "ellipse-outline"}
          size={10}
          color={i <= rating ? "#004c97" : "#97999b"}
          style={{ marginRight: 2 }}
        />
      ))}
    </View>
  );
}

export default function LoungeDetailScreen({ navigation, route }: any) {
  const { lounge } = route.params;

  const actionButtons = [
    { icon: 'navigation', label: 'Go', type: 'Feather' },
    { icon: 'headphones', label: 'Support', type: 'Feather' },
    { icon: 'star', label: 'Rate', type: 'Feather' },
    { icon: 'share', label: 'Share', type: 'Feather' },
    { icon: 'bookmark', label: 'Favorite', type: 'Feather' },
  ];

  return (
    <ScreenWrapper showBack={true}>
      

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
        {/* 2. Title Section */}
        <View style={styles.titleSection}>
          <Text style={styles.loungeName}>{lounge.name}</Text>
          <View style={styles.ratingRow}>
            <StarRating rating={lounge.rating} />
            <Text style={styles.ratingCount}>({lounge.rating} rating)</Text>
            {lounge.isOpen && (
              <View style={styles.openNowBadge}>
                <Text style={styles.openNowText}>OPEN NOW</Text>
              </View>
            )}
          </View>
        </View>

        {/* 3. Hero Image Container */}
      <View style={styles.heroWrapper}>
        <Image source={{ uri: lounge.image }} style={styles.heroImage} />
        
        {/* 4. Action Icons (Overlapping the bottom half of the image) */}
        <View style={styles.actionGridFloating}>
          {actionButtons.map((btn) => (
            <TouchableOpacity key={btn.label} style={styles.actionItem}>
              <View style={styles.iconCircle}>
                <Feather name={btn.icon as any} size={22} color="white" />
              </View>
              <Text style={styles.actionLabel}>{btn.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

{/* Spacer to prevent content from hiding under the floating buttons */}
        <View style={{ height: 40 }} />

        {/* 5. Location Section */}
        <View style={styles.locationSection}>
          <Text style={styles.sectionLabel}>LOCATION</Text>
          <View style={styles.locationHeaderRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.airportName}>{lounge.airport}</Text>
              <Text style={styles.terminalInfo}>{lounge.terminal} | 5.52 mi.</Text>
            </View>
            <TouchableOpacity style={styles.pillButton}>
              <Text style={styles.pillButtonText}>GET DIRECTIONS</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.descriptionText}>{lounge.accessInstructions}</Text>
        </View>

        {/* 6. Map Section */}
        <View style={styles.mapWrapper}>
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: lounge.coordinates.latitude,
              longitude: lounge.coordinates.longitude,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01,
            }}
          >
            <Marker coordinate={lounge.coordinates} />
          </MapView>
        </View>

        {/* 7. Fast Track */}
        <View style={styles.fastTrackSection}>
          <Text style={styles.fastTrackBody}>
            <Text style={{ fontWeight: 'bold', color: '#004c97' }}>Fast Track Available:</Text> {lounge.fastTrackCount} Fast Track gates open at this airport.
          </Text>
          <TouchableOpacity style={styles.widePillButton}>
            <Text style={styles.pillButtonText}>BOOK YOUR FAST TRACK LANE TODAY!</Text>
          </TouchableOpacity>
        </View>

         {/* 7. Hours */}
        <View style={styles.fastTrackSection}>
          <Text style={styles.fastTrackBody}>
            <Text style={{ fontWeight: 'bold', color: '#004c97' }}>HOURS</Text>
            
          </Text>
          <Text style={styles.fastTrackBody}>24 hours daily.</Text>
        </View>

        <View style={styles.fastTrackSection}>
          <Text style={styles.fastTrackBody}>
            <Text style={{ fontWeight: 'bold', color: '#004c97' }}>ADDITIONAL INFORMATION</Text>
            
          </Text>
          <Text style={styles.fastTrackBody}>Digital newspapers</Text>
        </View>

        {/* 8. Amenities (List Style) */}
        {/* <View style={styles.amenitiesSection}>
          <Text style={styles.sectionLabel}>AMENITIES</Text>
          <View style={styles.amenityList}>
            {lounge.amenities.map((item: string, index: number) => (
              <View key={index} style={styles.amenityRow}>
                 <Feather name="check" size={14} color="#00a3e0" />
                 <Text style={styles.amenityText}>{item}</Text>
              </View>
            ))}
          </View>
        </View> */}
        //         {/* Amenities */}
         <View style={styles.fastTrackSection}>
           <Text style={{ fontWeight: 'bold', color: '#004c97', paddingBottom: 10 }}>AMENITIES</Text>
           <View style={styles.amenitiesGrid}>
                {lounge.amenities.map((item: string, index: number) => (
              <AmenityItem key={index} name={item} />
            //  {lounge.amenities.map((amenity) => (
            //   <AmenityItem key={amenity} name={amenity} />
            ))}
          </View>
        </View>


        <View style={styles.fastTrackSection}>

          <Text style={styles.fastTrackBody}>
            <Text style={{ fontWeight: 'bold', color: '#004c97' }}>MEMBER FEE</Text> {lounge.pricing.memberFee}
          </Text>
          <Text style={styles.fastTrackBody}>
            <Text style={{ fontWeight: 'bold', color: '#004c97' }}>GUEST FEE</Text> {lounge.pricing.guestFee}
          </Text>
        </View>
        <View style={styles.fastTrackSection}>

          <Text style={styles.fastTrackBody}>
            <Text style={{ fontWeight: 'bold', color: '#004c97' }}>ENTRY CONDITIONS</Text>
          </Text>
          <Text style={styles.fastTrackBody}>
            {lounge.entryConditions}
          </Text>
        </View>

        <View style={{ height: 60 }} />
      </ScrollView>
    </ScreenWrapper>
  );
}

const styles = StyleSheet.create({
  amenitiesTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: '#002868',
    letterSpacing: 0.5,
    marginBottom: 12,
  },
  amenitiesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
    section: {
    backgroundColor: '#fff',
    marginTop: 10,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  heroWrapper: {
    paddingHorizontal: 25,
    marginTop: 20,
    position: 'relative', // Necessary for absolute positioning of children
    zIndex: 10,
  },
  actionGridFloating: {
    position: 'absolute',
    bottom: -35, // This pushes the icons down to sit halfway off the image
    left: 25,
    right: 25,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 10,
    zIndex: 20, // Ensures icons sit on top of everything
  },
  container: { flex: 1, backgroundColor: 'white' },
  scrollView: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    height: 60,
  },
  logo: { width: 40, height: 40, resizeMode: 'contain' },
  backPill: {
    flexDirection: 'row',
    backgroundColor: '#00a3e0',
    paddingVertical: 6,
    paddingHorizontal: 15,
    borderRadius: 20,
    alignItems: 'center',
  },
  backText: { color: 'white', fontWeight: 'bold', fontSize: 12, marginLeft: 4 },
  headerIcons: { flexDirection: 'row' },
  dot: { width: 8, height: 8, backgroundColor: '#009ca6', borderRadius: 4, position: 'absolute', right: 0 },

  titleSection: { paddingHorizontal: 25, paddingTop: 20 },
  loungeName: { fontSize: 35, fontWeight: 'bold', color: '#004c97', lineHeight: 40 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', marginTop: 10 },
  ratingStars: { flexDirection: 'row', marginRight: 8 },
  ratingCount: { color: '#97999b', fontSize: 14 },
  openNowBadge: { backgroundColor: '#00a3e0', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 15, marginLeft: 'auto' },
  openNowText: { color: 'white', fontWeight: 'bold', fontSize: 10 },

  imageContainer: { paddingHorizontal: 25, marginTop: 20 },
  heroImage: { width: '100%', height: 220, borderRadius: 15 },

  actionGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 25,
    marginTop: 25,
  },
  actionItem: { alignItems: 'center', width: 60 },
  iconCircle: {
    width: 45,
    height: 45,
    borderRadius: 22.5,
    backgroundColor: '#00a3e0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  actionLabel: { fontSize: 11, color: '#97999b', fontWeight: '500' },

  locationSection: { paddingHorizontal: 25, marginTop: 30 },
  sectionLabel: { color: '#97999b', fontWeight: 'bold', fontSize: 13, letterSpacing: 1, marginBottom: 10 },
  locationHeaderRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 15 },
  airportName: { color: '#004c97', fontSize: 18, fontWeight: 'bold' },
  terminalInfo: { color: '#004c97', fontSize: 16 },
  pillButton: { backgroundColor: '#00a3e0', borderRadius: 20, paddingVertical: 8, paddingHorizontal: 15 },
  pillButtonText: { color: 'white', fontWeight: 'bold', fontSize: 11 },
  descriptionText: { color: '#97999b', fontSize: 14, lineHeight: 22 },

  mapWrapper: { marginHorizontal: 25, height: 180, borderRadius: 15, overflow: 'hidden', marginTop: 20 },
  map: { flex: 1 },

  fastTrackSection: { paddingHorizontal: 25, marginTop: 25 },
  fastTrackBody: { color: '#444', fontSize: 14, marginBottom: 15 },
  widePillButton: { backgroundColor: '#00a3e0', borderRadius: 25, paddingVertical: 12, alignItems: 'center', width: 251, alignSelf: 'center' },

  amenitiesSection: { paddingHorizontal: 25, marginTop: 30 },
  amenityList: { marginTop: 10 },
  amenityRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 10, width: '50%' },
  amenityText: { color: '#444', marginLeft: 10, fontSize: 14 },
});


// import React, { useState } from 'react';
// import {
//   View,
//   Text,
//   ScrollView,
//   Image,
//   TouchableOpacity,
//   StyleSheet,
//   Linking,
//   Alert,
//   StatusBar,
// } from 'react-native';
// import MapView, { Marker } from 'react-native-maps';
// import { Ionicons } from '@expo/vector-icons';
// import { NativeStackNavigationProp } from '@react-navigation/native-stack';
// import { RouteProp } from '@react-navigation/native';
// import { RootStackParamList } from '../navigation/AppNavigator';
// import Header from '../components/Header';
// import AmenityItem from '../components/AmenityItem';
// import { SafeAreaView } from 'react-native-safe-area-context';


// type Props = {
//   navigation: NativeStackNavigationProp<RootStackParamList, 'LoungeDetail'>;
//   route: RouteProp<RootStackParamList, 'LoungeDetail'>;
// };

// function StarRating({ rating }: { rating: number }) {
//   return (
//     <View style={{ flexDirection: 'row' }}>
//       {[1, 2, 3, 4, 5].map((i) => (
//         <Ionicons
//           key={i}
//           name={i <= rating ? 'star' : 'star-outline'}
//           size={16}
//           color="#BFA046"
//         />
//       ))}
//     </View>
//   );
// }

// export default function LoungeDetailScreen({ navigation, route }: Props) {
//   const { lounge } = route.params;
//   const [additionalInfoExpanded, setAdditionalInfoExpanded] = useState(false);

//   const openDirections = () => {
//     const url = `maps://app?daddr=${lounge.coordinates.latitude},${lounge.coordinates.longitude}`;
//     Linking.openURL(url).catch(() =>
//       Linking.openURL(
//         `https://maps.google.com/?q=${lounge.coordinates.latitude},${lounge.coordinates.longitude}`
//       )
//     );
//   };

//   const actionButtons = [
//     { icon: 'heart-outline', label: 'Favourite' },
//     { icon: 'star-outline', label: 'Rate' },
//     { icon: 'share-social-outline', label: 'Share' },
//     { icon: 'map-outline', label: 'Map' },
//     { icon: 'list-outline', label: 'Amenities' },
//   ];

//   return (
//     <SafeAreaView style={styles.container}>
    
//     <View style={styles.root}>
//       <StatusBar barStyle="light-content" backgroundColor="#002868" />
//       <Header
//         onBack={() => navigation.goBack()}
//         backLabel="BACK"
//         showShare
//         onShare={() => Alert.alert('Share', 'Share functionality coming soon.')}
//       />

//       <ScrollView showsVerticalScrollIndicator={false}>
//         {/* Title Block */}
//         <View style={styles.titleBlock}>
//           <Text style={styles.name}>{lounge.name}</Text>
//           <View style={styles.ratingRow}>
//             <StarRating rating={lounge.rating} />
//             <Text style={styles.reviewCount}>
//               {lounge.reviewCount} rating{lounge.reviewCount !== 1 ? 's' : ''}
//             </Text>
//             {lounge.isOpen && (
//               <View style={styles.openBadge}>
//                 <Text style={styles.openText}>OPEN NOW</Text>
//               </View>
//             )}
//           </View>
//         </View>

//         {/* Hero Image */}
//         <Image source={{ uri: lounge.image }} style={styles.heroImage} resizeMode="cover" />

//         {/* Action Buttons */}
//         <View style={styles.actionRow}>
//           {actionButtons.map((btn) => (
//             <TouchableOpacity key={btn.label} style={styles.actionBtn} onPress={() => {}}>
//               <Ionicons name={btn.icon as any} size={22} color="#002868" />
//               <Text style={styles.actionLabel}>{btn.label}</Text>
//             </TouchableOpacity>
//           ))}
//         </View>

//         {/* Location */}
//         <View style={styles.section}>
//           <View style={styles.locationRow}>
//             <View style={styles.locationInfo}>
//               <Ionicons name="location-outline" size={18} color="#002868" />
//               <View style={styles.locationText}>
//                 <Text style={styles.locationName}>{lounge.airport}</Text>
//                 <Text style={styles.locationTerminal}>{lounge.terminal}</Text>
//               </View>
//             </View>
//             <TouchableOpacity style={styles.directionsBtn} onPress={openDirections}>
//               <Text style={styles.directionsBtnText}>GET DIRECTIONS</Text>
//             </TouchableOpacity>
//           </View>

//           <Text style={styles.accessText}>{lounge.accessInstructions}</Text>
//         </View>

//         {/* Map */}
//         <View style={styles.mapContainer}>
//           <MapView
//             style={styles.map}
//             initialRegion={{
//               latitude: lounge.coordinates.latitude,
//               longitude: lounge.coordinates.longitude,
//               latitudeDelta: 0.01,
//               longitudeDelta: 0.01,
//             }}
//           >
//             <Marker
//               coordinate={lounge.coordinates}
//               title={lounge.name}
//               description={lounge.airport}
//             />
//           </MapView>
//         </View>

//         {/* Fast Track */}
//         {lounge.fastTrackAvailable && (
//           <View style={styles.fastTrackBlock}>
//             <View style={styles.fastTrackInfo}>
//               <Ionicons name="flash-outline" size={18} color="#002868" />
//               <Text style={styles.fastTrackText}>
//                 Fast Track Available: {lounge.fastTrackCount} Fast Track gates open at this airport.
//               </Text>
//             </View>
//             <TouchableOpacity style={styles.fastTrackBtn}>
//               <Text style={styles.fastTrackBtnText}>BOOK YOUR FAST TRACK LANE TODAY!</Text>
//             </TouchableOpacity>
//           </View>
//         )}

//         {/* Additional Information */}
//         <View style={styles.section}>
//           <TouchableOpacity
//             style={styles.additionalHeader}
//             onPress={() => setAdditionalInfoExpanded(!additionalInfoExpanded)}
//           >
//             <Text style={styles.additionalTitle}>ADDITIONAL INFORMATION</Text>
//             <Ionicons
//               name={additionalInfoExpanded ? 'chevron-up' : 'chevron-down'}
//               size={18}
//               color="#002868"
//             />
//           </TouchableOpacity>
//           {additionalInfoExpanded && (
//             <View style={styles.additionalContent}>
//               <View style={styles.infoRow}>
//                 <Ionicons name="time-outline" size={16} color="#555" />
//                 <Text style={styles.infoText}>{lounge.hours}</Text>
//               </View>
//               <Text style={styles.infoNote}>Digital newspapers/magazines available only.</Text>
//             </View>
//           )}
//         </View>

//         {/* Amenities */}
//         <View style={styles.section}>
//           <Text style={styles.amenitiesTitle}>AMENITIES</Text>
//           <View style={styles.amenitiesGrid}>
//             {lounge.amenities.map((amenity) => (
//               <AmenityItem key={amenity} name={amenity} />
//             ))}
//           </View>
//         </View>

//         {/* Member Fee */}
//         <View style={styles.memberFeeBlock}>
//           <Ionicons name="information-circle-outline" size={16} color="#555" />
//           <Text style={styles.memberFeeText}>
//             Member Fee: Please contact your Diners Club card issuer and issuer regarding your club features and benefits, including membership.
//           </Text>
//         </View>

//         <View style={{ height: 40 }} />
//       </ScrollView>
//     </View>
//     </SafeAreaView>
//   );
// }

// const styles = StyleSheet.create({
//     container: { flex: 1, backgroundColor: '#f7f7f7' },
//   root: {
//     flex: 1,
//     backgroundColor: '#F0F4F8',
//   },
//   titleBlock: {
//     backgroundColor: '#fff',
//     paddingHorizontal: 20,
//     paddingVertical: 16,
//   },
//   name: {
//     fontSize: 22,
//     fontWeight: '800',
//     color: '#002868',
//     marginBottom: 8,
//     lineHeight: 28,
//   },
//   ratingRow: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     flexWrap: 'wrap',
//     gap: 8,
//   },
//   reviewCount: {
//     fontSize: 12,
//     color: '#777',
//   },
//   openBadge: {
//     backgroundColor: '#2E7D32',
//     borderRadius: 4,
//     paddingHorizontal: 8,
//     paddingVertical: 3,
//   },
//   openText: {
//     color: '#fff',
//     fontSize: 10,
//     fontWeight: '700',
//   },
//   heroImage: {
//     width: '100%',
//     height: 200,
//   },
//   actionRow: {
//     flexDirection: 'row',
//     backgroundColor: '#fff',
//     paddingVertical: 12,
//     borderBottomWidth: 1,
//     borderBottomColor: '#eee',
//   },
//   actionBtn: {
//     flex: 1,
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
//   actionLabel: {
//     fontSize: 9,
//     color: '#002868',
//     fontWeight: '600',
//     marginTop: 3,
//   },
//   section: {
//     backgroundColor: '#fff',
//     marginTop: 10,
//     paddingHorizontal: 16,
//     paddingVertical: 14,
//   },
//   locationRow: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     marginBottom: 12,
//   },
//   locationInfo: {
//     flexDirection: 'row',
//     alignItems: 'flex-start',
//     flex: 1,
//     marginRight: 10,
//   },
//   locationText: {
//     marginLeft: 6,
//     flex: 1,
//   },
//   locationName: {
//     fontSize: 13,
//     fontWeight: '700',
//     color: '#002868',
//   },
//   locationTerminal: {
//     fontSize: 12,
//     color: '#666',
//     marginTop: 1,
//   },
//   directionsBtn: {
//     backgroundColor: '#002868',
//     paddingHorizontal: 12,
//     paddingVertical: 8,
//     borderRadius: 5,
//   },
//   directionsBtnText: {
//     color: '#fff',
//     fontSize: 10,
//     fontWeight: '700',
//     letterSpacing: 0.5,
//   },
//   accessText: {
//     fontSize: 12,
//     color: '#444',
//     lineHeight: 18,
//   },
//   mapContainer: {
//     marginTop: 10,
//     height: 200,
//     overflow: 'hidden',
//   },
//   map: {
//     flex: 1,
//   },
//   fastTrackBlock: {
//     backgroundColor: '#EEF4FF',
//     marginTop: 10,
//     padding: 16,
//     borderLeftWidth: 4,
//     borderLeftColor: '#002868',
//   },
//   fastTrackInfo: {
//     flexDirection: 'row',
//     alignItems: 'flex-start',
//     marginBottom: 12,
//   },
//   fastTrackText: {
//     fontSize: 12,
//     color: '#333',
//     marginLeft: 8,
//     flex: 1,
//     lineHeight: 18,
//   },
//   fastTrackBtn: {
//     backgroundColor: '#002868',
//     borderRadius: 5,
//     paddingVertical: 10,
//     alignItems: 'center',
//   },
//   fastTrackBtnText: {
//     color: '#fff',
//     fontSize: 12,
//     fontWeight: '700',
//     letterSpacing: 0.5,
//   },
//   additionalHeader: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//   },
//   additionalTitle: {
//     fontSize: 12,
//     fontWeight: '800',
//     color: '#002868',
//     letterSpacing: 0.5,
//   },
//   additionalContent: {
//     marginTop: 12,
//   },
//   infoRow: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     marginBottom: 6,
//   },
//   infoText: {
//     fontSize: 12,
//     color: '#444',
//     marginLeft: 8,
//   },
//   infoNote: {
//     fontSize: 11,
//     color: '#666',
//     fontStyle: 'italic',
//     marginTop: 4,
//   },
//   amenitiesTitle: {
//     fontSize: 12,
//     fontWeight: '800',
//     color: '#002868',
//     letterSpacing: 0.5,
//     marginBottom: 12,
//   },
//   amenitiesGrid: {
//     flexDirection: 'row',
//     flexWrap: 'wrap',
//   },
//   memberFeeBlock: {
//     flexDirection: 'row',
//     alignItems: 'flex-start',
//     backgroundColor: '#fff',
//     marginTop: 10,
//     padding: 16,
//   },
//   memberFeeText: {
//     fontSize: 11,
//     color: '#666',
//     marginLeft: 8,
//     flex: 1,
//     lineHeight: 16,
//     fontStyle: 'italic',
//   },
// });
