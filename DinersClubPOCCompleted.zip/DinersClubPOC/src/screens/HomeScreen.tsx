import React from 'react';
import {
  View,
  Text,
  ScrollView,
  FlatList,
  ImageBackground,
  TouchableOpacity,
  StyleSheet,
  Alert,
  StatusBar,
  Dimensions,
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import FeatureTile from '../components/FeatureTile';
import { featureTiles } from '../data/mockData';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ScreenWrapper } from '../components/ScreenWrapper';

 const { width } = Dimensions.get('window');

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'Home'>;
};

export default function HomeScreen({ navigation }: Props) {
  const handleTilePress = (label: string) => {
    if (label === 'Airport Services') {
      // Navigate to airport services if needed
      Alert.alert(label, 'This feature is coming soon.');
    } else {
      Alert.alert(label, 'This feature is coming soon.');
    }
  };

  const renderTile = ({ item }: { item: typeof featureTiles[0] }) => (
    <FeatureTile
      label={item.label}
      icon={item.icon}
      image={item.image}
      onPress={() => handleTilePress(item.label)}
    />
  );

  return (
  //   <SafeAreaView style={styles.container}>
  //   <View style={styles.root}>
  //     <StatusBar barStyle="light-content" backgroundColor="#002868" />

  //     {/* Top Header */}
  //     <View style={styles.header}>
  //       <View style={styles.logo}>
  //         <Text style={styles.logoText}>D</Text>
  //       </View>
  //     </View>

  //     <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
  //       {/* Welcome Block */}
  //       <View style={styles.welcomeBlock}>
  //         <Text style={styles.welcomeText}>Welcome,{'\n'}Clubmember</Text>
  //       </View>

  //       {/* Explore Lounges Hero Card */}
  //       <TouchableOpacity
  //         style={styles.heroCard}
  //         onPress={() => navigation.navigate('ExploreLounges')}
  //         activeOpacity={0.9}
  //       >
  //         <ImageBackground
  //           source={{ uri: 'https://images.unsplash.com/photo-1559329007-40df8a9345d8?w=800' }}
  //           style={styles.heroImage}
  //           imageStyle={{ borderRadius: 10 }}
  //         >
  //           <View style={styles.heroOverlay}>
  //             <Text style={styles.heroLabel}>Explore Lounges</Text>
  //           </View>
  //         </ImageBackground>
  //       </TouchableOpacity>

  //       {/* Feature Grid */}
  //       <FlatList
  //         data={featureTiles}
  //         renderItem={renderTile}
  //         keyExtractor={(item) => item.id}
  //         numColumns={2}
  //         scrollEnabled={false}
  //         contentContainerStyle={styles.grid}
  //       />

  //         {/* 2. DYNAMIC GRID RENDERING */}
  //       <View style={styles.gridContainer}>
  //         {featureTiles.map((item) => (
  //           <TouchableOpacity key={item.id} style={styles.gridItem}>
  //             <ImageBackground 
  //               source={{ uri: item.image }} 
  //               style={styles.logo} 
  //               imageStyle={{ borderRadius: 12 }}
  //             >
  //               <View style={styles.iconBadge}>
  //                 <MaterialCommunityIcons name={item.icon as any} size={16} color="white" />
  //               </View>
  //               <View style={styles.gridTitleContainer}>
  //                 <Text style={styles.gridTitle} numberOfLines={1}>{item.label}</Text>
  //               </View>
  //             </ImageBackground>
  //           </TouchableOpacity>
  //         ))}
  //       </View>

  //     </ScrollView>
  //   </View>
  //   </SafeAreaView>
  // );

    <ScreenWrapper showBack={false}>
      <ScrollView showsVerticalScrollIndicator={false}>
        
        {/* Static Header Section */}
        <View style={styles.header}>
          {/* <View style={styles.topIcons}>
            <View style={styles.logoCircle}>
              <MaterialCommunityIcons name="shield-outline" size={24} color="#004c97" />
            </View>
            <TouchableOpacity style={styles.notificationBtn}>
              <Feather name="bell" size={24} color="#97999b" />
              <View style={styles.badge} />
            </TouchableOpacity>
          </View> */}
          <Text style={styles.welcomeText}>Welcome,{"\n"}Clubmember</Text>
          <View style={styles.locationRow}>
    <Text style={styles.noLocationText}>No Location Selected</Text>
    <TouchableOpacity style={styles.locationIconCircle}>
      <MaterialCommunityIcons name="map-marker-radius" size={22} color="white" />
    </TouchableOpacity>
  </View>
          {/* <View style={styles.locationContainer}>
            <Text style={styles.locationText}>No Location Selected</Text>
            <MaterialCommunityIcons name="map-marker-outline" size={20} color="#00a3e0" />
          </View> */}
          <Text style={styles.subLabel}>DINERS CLUB® TRAVEL TOOLS</Text>
        </View>

        

        {/* Hero Section */}
        <TouchableOpacity style={styles.heroCard} onPress={() => navigation.navigate('ExploreLounges')}>
          <ImageBackground 
            source={{ uri: 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?q=80&w=800' }} 
            style={styles.heroImage}
            imageStyle={{ borderRadius: 12 }}
          >
            <View style={styles.heroOverlay}>
              <Text style={styles.heroTitle}>Explore Lounges</Text>
              <Feather name="arrow-right" size={24} color="#00a3e0" />
            </View>
          </ImageBackground>
        </TouchableOpacity>

        {/* 2. DYNAMIC GRID RENDERING */}
        <View style={styles.gridContainer}>
          {featureTiles.map((item) => (
            <TouchableOpacity key={item.id} style={styles.gridItem}>
              <ImageBackground 
                source={{ uri: item.image }} 
                style={styles.gridImage} 
                imageStyle={{ borderRadius: 12 }}
              >
                <View style={styles.iconBadge}>
                  <MaterialCommunityIcons name={item.icon as any} size={16} color="white" />
                </View>
                <View style={styles.gridTitleContainer}>
                  <Text style={styles.gridTitle} numberOfLines={1}>{item.label}</Text>
                </View>
              </ImageBackground>
            </TouchableOpacity>
          ))}
        </View>

        {/* Bottom Padding */}
        <View style={{ height: 40 }} />
      </ScrollView>
      </ScreenWrapper>
  );
}

// const styles = StyleSheet.create({
//   root: {
//     flex: 1,
//     backgroundColor: '#F0F4F8',
//   },
//   header: {
//     backgroundColor: '#002868',
//     alignItems: 'center',
//     paddingTop: 50,
//     paddingBottom: 14,
//   },
//   logo: {
//     width: 44,
//     height: 44,
//     borderRadius: 22,
//     backgroundColor: '#fff',
//     alignItems: 'center',
//     justifyContent: 'center',
//     borderWidth: 2,
//     borderColor: '#BFA046',
//   },
//   logoText: {
//     color: '#002868',
//     fontSize: 22,
//     fontWeight: '900',
//     fontStyle: 'italic',
//   },
//   scroll: {
//     flex: 1,
//   },
//   welcomeBlock: {
//     backgroundColor: '#002868',
//     paddingHorizontal: 20,
//     paddingBottom: 24,
//   },
//   welcomeText: {
//     color: '#fff',
//     fontSize: 28,
//     fontWeight: '800',
//     lineHeight: 36,
//   },
//   heroCard: {
//     marginHorizontal: 16,
//     marginTop: 16,
//     marginBottom: 8,
//     borderRadius: 10,
//     overflow: 'hidden',
//     height: 140,
//     elevation: 4,
//     shadowColor: '#000',
//     shadowOffset: { width: 0, height: 2 },
//     shadowOpacity: 0.15,
//     shadowRadius: 5,
//   },
//   heroImage: {
//     flex: 1,
//     justifyContent: 'flex-end',
//   },
//   heroOverlay: {
//     backgroundColor: 'rgba(0,20,80,0.5)',
//     padding: 14,
//   },
//   heroLabel: {
//     color: '#fff',
//     fontSize: 18,
//     fontWeight: '800',
//     letterSpacing: 0.5,
//   },
//   grid: {
//     paddingHorizontal: 12,
//     paddingBottom: 24,
//     paddingTop: 8,
//   },
//   container: { flex: 1, backgroundColor: '#f7f7f7' },
//   header: { paddingHorizontal: 24, paddingTop: 20 },
//   topIcons: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30 },
//   logoCircle: { width: 40, height: 40, borderRadius: 20, borderWidth: 2, borderColor: '#004c97', justifyContent: 'center', alignItems: 'center' },
//   notificationBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
//   badge: { position: 'absolute', top: 8, right: 8, width: 8, height: 8, borderRadius: 4, backgroundColor: '#009ca6' },
//   welcomeText: { fontSize: 36, fontWeight: '700', color: '#004c97', lineHeight: 40 },
//   locationContainer: { flexDirection: 'row', alignItems: 'center', marginTop: 12 },
//   locationText: { fontSize: 16, color: '#97999b', marginRight: 8 },
//   subLabel: { fontSize: 11, color: '#97999b', letterSpacing: 1.5, marginTop: 24, fontWeight: '600' },
//   heroCard: { marginHorizontal: 16, marginTop: 16, height: 180 },
//   heroImage: { flex: 1, justifyContent: 'flex-end' },
//   heroOverlay: { backgroundColor: '#041e42', height: 50, borderBottomLeftRadius: 12, borderBottomRightRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20 },
//   heroTitle: { color: 'white', fontSize: 18, fontWeight: '600' },
//   gridContainer: { flexDirection: 'row', flexWrap: 'wrap', padding: 8, justifyContent: 'flex-start' },
//   gridItem: { width: (width / 2) - 16, height: 140, margin: 8 },
//   gridImage: { flex: 1, justifyContent: 'flex-end' },
//   iconBadge: { position: 'absolute', top: 8, right: 8, backgroundColor: '#00a3e0', borderRadius: 12, padding: 4, elevation: 3 },
//   gridTitleContainer: { backgroundColor: '#041e42', height: 40, borderBottomLeftRadius: 12, borderBottomRightRadius: 12, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 5 },
//   gridTitle: { color: 'white', fontSize: 13, fontWeight: '500', textAlign: 'center' },
// });

const styles = StyleSheet.create({
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between', // Pushes icon to the right
    marginBottom: 24,                // Green marker '28'
    marginTop:18
  },
  noLocationText: {
    fontSize: 18,
    color: '#97999b',       // Gotham Book #97999b
    fontWeight: '400',
  },
  locationIconCircle: {
    width: 38,              // Green marker '38'
    height: 38,
    borderRadius: 19,
    backgroundColor: '#00a3e0', // Fill: #00a3e0
    justifyContent: 'center',
    alignItems: 'center',
    // Stroke: #97999b (0.5px)
    borderWidth: 0.5,
    borderColor: '#97999b',
  },
  container: { flex: 1, backgroundColor: '#f7f7f7' },
  header: { paddingHorizontal: 24, paddingTop: 20 },
  topIcons: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30 },
  logoCircle: { width: 40, height: 40, borderRadius: 20, borderWidth: 2, borderColor: '#004c97', justifyContent: 'center', alignItems: 'center' },
  notificationBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  badge: { position: 'absolute', top: 8, right: 8, width: 8, height: 8, borderRadius: 4, backgroundColor: '#009ca6' },
  welcomeText: { fontSize: 36, fontWeight: '700', color: '#004c97', lineHeight: 40 },
  locationContainer: { flexDirection: 'row', alignItems: 'center', marginTop: 12 },
  locationText: { fontSize: 16, color: '#97999b', marginRight: 8 },
  subLabel: { fontSize: 11, color: '#97999b', letterSpacing: 1.5, marginTop: 0, fontWeight: '600' },
  heroCard: { marginHorizontal: 16, marginTop: 16, height: 180 },
  heroImage: { flex: 1, justifyContent: 'flex-end' },
  heroOverlay: { backgroundColor: '#041e42', height: 50, borderBottomLeftRadius: 12, borderBottomRightRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20 },
  heroTitle: { color: 'white', fontSize: 18, fontWeight: '600' },
  gridContainer: { flexDirection: 'row', flexWrap: 'wrap', padding: 8, justifyContent: 'flex-start' },
  gridItem: { width: (width / 2) - 24, height: 140, margin: 8 },
  gridImage: { flex: 1, justifyContent: 'flex-end' },
  iconBadge: { position: 'absolute', top: 8, right: 8, backgroundColor: '#00a3e0', borderRadius: 12, padding: 4, elevation: 3 },
  gridTitleContainer: { backgroundColor: '#041e42', height: 40, borderBottomLeftRadius: 12, borderBottomRightRadius: 12, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 5 },
  gridTitle: { color: 'white', fontSize: 13, fontWeight: '500', textAlign: 'center' },
});
