import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Feather, Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

// Standardize the export
export default function GlobalHeader({ showBackButton,backLabel = "BACK" }: { showBackButton?: boolean, backLabel?: string }) {
  const navigation = useNavigation();

  return (
    <View style={styles.headerContainer}>
      {/* Diners Club Logo (Left) */}
      <View style={styles.sideSection}>
        <Image 
          source={{ uri: 'https://images.icon-icons.com/1178/PNG/512/diners-club_82069.png' }} 
          style={styles.logo} 
        />
      </View>

      {/* Back Pill (Center) */}
      <View style={styles.centerSection}>
        {showBackButton && (
          <TouchableOpacity style={styles.backPill} onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={16} color="white" />
            <Text style={styles.backText}>{backLabel}</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Notification & Hamburger (Right) */}
      <View style={[styles.sideSection, styles.rightIcons]}>
        <View style={styles.bellWrapper}>
          <Feather name="bell" size={22} color="#97999b" />
          <View style={styles.badge}>
            <Text style={styles.badgeText}>2</Text>
          </View>
        </View>
        <TouchableOpacity style={{ marginLeft: 15 }}>
          <Feather name="menu" size={24} color="#97999b" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    backgroundColor: 'white',
  },
  sideSection: { flex: 1 },
  centerSection: { flex: 2, alignItems: 'flex-end' },
  logo: { width: 100, height: 100, resizeMode: 'contain', marginLeft: -30 },
  backPill: {
    flexDirection: 'row',
    backgroundColor: '#00a3e0',
    paddingVertical: 6,
    paddingHorizontal: 16,
    borderRadius: 20,
    alignItems: 'center',
  },
  backText: { color: 'white', fontWeight: 'bold', fontSize: 11, marginLeft: 4 },
  rightIcons: { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center' },
  bellWrapper: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#eee',
    justifyContent: 'center',
    alignItems: 'center',
  },
  badge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#009ca6',
    width: 14,
    height: 14,
    borderRadius: 7,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: { color: 'white', fontSize: 8, fontWeight: 'bold' },
});