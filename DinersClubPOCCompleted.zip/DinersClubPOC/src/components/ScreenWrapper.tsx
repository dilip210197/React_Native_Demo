import { View, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import GlobalHeader from '../screens/GlobalHeader';

export const ScreenWrapper = ({ children, showBack, backLabel }: any) => (
  <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
    <GlobalHeader showBackButton={showBack} backLabel={backLabel} />
    <View style={{ flex: 1 }}>
      {children}
    </View>
  </SafeAreaView>
);