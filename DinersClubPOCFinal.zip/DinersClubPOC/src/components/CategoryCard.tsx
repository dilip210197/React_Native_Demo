import React from 'react';
import { TouchableOpacity, Text, ImageBackground, StyleSheet, View } from 'react-native';

type CategoryCardProps = {
  title: string;
  subtitle: string;
  image: string;
  onPress: () => void;
};

export default function CategoryCard({ title, subtitle, image, onPress }: CategoryCardProps) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.85}>
      <ImageBackground
        source={{ uri: image }}
        style={styles.image}
        imageStyle={styles.imageStyle}
      >
        <View style={styles.overlay}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.subtitle}>{subtitle}</Text>
        </View>
      </ImageBackground>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 4,
    borderRadius: 8,
    overflow: 'hidden',
    height: 160,
  },
  image: {
    flex: 1,
  },
  imageStyle: {
    borderRadius: 8,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,20,60,0.6)',
    justifyContent: 'flex-end',
    padding: 12,
  },
  title: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 1,
  },
  subtitle: {
    color: '#ddd',
    fontSize: 11,
    marginTop: 3,
    lineHeight: 15,
  },
});
