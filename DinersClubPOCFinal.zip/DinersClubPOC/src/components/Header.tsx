import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

type HeaderProps = {
  onBack?: () => void;
  backLabel?: string;
  showSearch?: boolean;
  showShare?: boolean;
  onSearch?: () => void;
  onShare?: () => void;
};

export default function Header({
  onBack,
  backLabel = 'HOME',
  showSearch = false,
  showShare = false,
  onSearch,
  onShare,
}: HeaderProps) {
  return (
    <View style={styles.container}>
      {onBack ? (
        <TouchableOpacity style={styles.backBtn} onPress={onBack}>
          <Ionicons name="chevron-back" size={16} color="#fff" />
          <Text style={styles.backLabel}>{backLabel}</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.placeholder} />
      )}

      <View style={styles.logoContainer}>
        <View style={styles.logo}>
          <Text style={styles.logoText}>D</Text>
        </View>
      </View>

      <View style={styles.rightActions}>
        {showSearch && (
          <TouchableOpacity onPress={onSearch} style={styles.iconBtn}>
            <Ionicons name="search" size={22} color="#fff" />
          </TouchableOpacity>
        )}
        {showShare && (
          <TouchableOpacity onPress={onShare} style={styles.iconBtn}>
            <Ionicons name="share-social-outline" size={22} color="#fff" />
          </TouchableOpacity>
        )}
        {!showSearch && !showShare && <View style={styles.placeholder} />}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#002868',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  backBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#00448B',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 4,
    minWidth: 70,
  },
  backLabel: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
    marginLeft: 2,
  },
  logoContainer: {
    alignItems: 'center',
  },
  logo: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#BFA046',
  },
  logoText: {
    color: '#002868',
    fontSize: 20,
    fontWeight: '900',
    fontStyle: 'italic',
  },
  rightActions: {
    flexDirection: 'row',
    minWidth: 70,
    justifyContent: 'flex-end',
  },
  iconBtn: {
    marginLeft: 12,
  },
  placeholder: {
    minWidth: 70,
  },
});
