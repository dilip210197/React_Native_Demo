import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const amenityIcons: Record<string, string> = {
  'Air Conditioning': 'snow-outline',
  'Alcoholic Beverages': 'wine-outline',
  'Conference Facilities': 'business-outline',
  'Disabled Access': 'accessibility-outline',
  'Flight Info Monitors': 'tv-outline',
  'Newspapers & Magazines': 'newspaper-outline',
  'Non-Smoking': 'ban-outline',
  'Food & Drinks': 'restaurant-outline',
  'Shower Facilities': 'water-outline',
  'Television': 'desktop-outline',
};

export default function AmenityItem({ name }: { name: string }) {
  const icon = amenityIcons[name] ?? 'checkmark-circle-outline';
  return (
    <View style={styles.container}>
      <Ionicons name={icon as any} size={18} color="#002868" />
      <Text style={styles.label}>{name}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '50%',
    paddingVertical: 6,
    paddingHorizontal: 4,
  },
  label: {
    fontSize: 12,
    color: '#333',
    marginLeft: 8,
    flexShrink: 1,
  },
});
