import React from 'react';
import { TouchableOpacity, Text, ImageBackground, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

type FeatureTileProps = {
  label: string;
  icon: string;
  image: string;
  onPress: () => void;
};

export default function FeatureTile({ label, icon, image, onPress }: FeatureTileProps) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.8}>
      <ImageBackground
        source={{ uri: image }}
        style={styles.image}
        imageStyle={styles.imageStyle}
      >
        <View style={styles.overlay}>
          <Ionicons name={icon as any} size={28} color="#fff" />
          <Text style={styles.label}>{label}</Text>
        </View>
      </ImageBackground>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 4,
    borderRadius: 8,
    overflow: 'hidden',
    height: 100,
  },
  image: {
    flex: 1,
  },
  imageStyle: {
    borderRadius: 8,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,30,80,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
  },
  label: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
    marginTop: 6,
  },
});
