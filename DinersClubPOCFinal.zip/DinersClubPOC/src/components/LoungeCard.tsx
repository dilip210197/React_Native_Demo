import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Lounge } from '../data/mockData';

type LoungeCardProps = {
  lounge: Lounge;
  onPress: () => void;
};

function StarRating({ rating }: { rating: number }) {
  return (
    <View style={{ flexDirection: 'row' }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Ionicons
          key={i}
          name={i <= rating ? 'star' : 'star-outline'}
          size={13}
          color="#BFA046"
        />
      ))}
    </View>
  );
}

export default function LoungeCard({ lounge, onPress }: LoungeCardProps) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.85}>
      <Image source={{ uri: lounge.image }} style={styles.image} />
      <View style={styles.info}>
        <View style={styles.badges}>
          {lounge.isOpen && (
            <View style={styles.openBadge}>
              <Text style={styles.openText}>OPEN NOW</Text>
            </View>
          )}
          {lounge.isNew && (
            <View style={styles.newBadge}>
              <Text style={styles.newText}>NEW</Text>
            </View>
          )}
        </View>
        <Text style={styles.name} numberOfLines={2}>{lounge.name}</Text>
        <Text style={styles.airport} numberOfLines={1}>{lounge.airport}</Text>
        <Text style={styles.terminal} numberOfLines={1}>{lounge.terminal}</Text>
        <View style={styles.ratingRow}>
          <StarRating rating={lounge.rating} />
          <Text style={styles.reviewCount}>({lounge.reviewCount})</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.viewBtn} onPress={onPress}>
        <Text style={styles.viewBtnText}>VIEW</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    marginHorizontal: 16,
    marginVertical: 6,
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  image: {
    width: 110,
    height: 110,
  },
  info: {
    flex: 1,
    padding: 10,
    justifyContent: 'center',
  },
  badges: {
    flexDirection: 'row',
    marginBottom: 4,
  },
  openBadge: {
    backgroundColor: '#2E7D32',
    borderRadius: 3,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginRight: 4,
  },
  openText: {
    color: '#fff',
    fontSize: 9,
    fontWeight: '700',
  },
  newBadge: {
    backgroundColor: '#1565C0',
    borderRadius: 3,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  newText: {
    color: '#fff',
    fontSize: 9,
    fontWeight: '700',
  },
  name: {
    fontSize: 13,
    fontWeight: '700',
    color: '#002868',
    marginBottom: 2,
  },
  airport: {
    fontSize: 11,
    color: '#555',
  },
  terminal: {
    fontSize: 11,
    color: '#777',
    marginBottom: 4,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  reviewCount: {
    fontSize: 11,
    color: '#888',
    marginLeft: 4,
  },
  viewBtn: {
    backgroundColor: '#002868',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 12,
  },
  viewBtnText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
  },
});
