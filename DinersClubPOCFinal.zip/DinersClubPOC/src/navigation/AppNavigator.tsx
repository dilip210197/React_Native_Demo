import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Lounge } from '../data/mockData';

import HomeScreen from '../screens/HomeScreen';
import ExploreLoungesScreen from '../screens/ExploreLoungesScreen';
import LoungeDetailScreen from '../screens/LoungeDetailScreen';

export type RootStackParamList = {
  Home: undefined;
  ExploreLounges: undefined;
  LoungeDetail: { lounge: Lounge };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="ExploreLounges" component={ExploreLoungesScreen} />
        <Stack.Screen name="LoungeDetail" component={LoungeDetailScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
