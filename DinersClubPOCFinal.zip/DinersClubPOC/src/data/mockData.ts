export type Lounge = {
  id: string;
  name: string;
  airport: string;
  terminal: string;
  rating: number;
  reviewCount: number;
  isOpen: boolean;
  isNew: boolean;
  coordinates: { latitude: number; longitude: number };
  amenities: string[];
  accessInstructions: string;
  fastTrackAvailable: boolean;
  fastTrackCount: number;
  image: string; // URL placeholder
  hours: string;
};

export const lounges: Lounge[] = [
  {
    id: '1',
    name: 'The Club LIM (International)',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'International Pier',
    rating: 4,
    reviewCount: 1,
    isOpen: true,
    isNew: false,
    coordinates: { latitude: -12.0219, longitude: -77.1143 },
    amenities: [
      'Air Conditioning',
      'Alcoholic Beverages',
      'Conference Facilities',
      'Disabled Access',
      'Flight Info Monitors',
      'Newspapers & Magazines',
      'Non-Smoking',
      'Food & Drinks',
      'Shower Facilities',
      'Television',
    ],
    accessInstructions:
      'Airside – pass through the main Security Checkpoint and walk right while following the signs to "Airport Lounges". Take the escalator to the Mezzanine level and walk through the corridor to find the lounge. Available to International flights only.',
    fastTrackAvailable: true,
    fastTrackCount: 5,
    image: 'https://images.unsplash.com/photo-1559329007-40df8a9345d8?w=800',
    hours: '6 hours daily',
  },
  {
    id: '2',
    name: 'La Bonbonniere',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'International Pier',
    rating: 4,
    reviewCount: 8,
    isOpen: true,
    isNew: false,
    coordinates: { latitude: -12.022, longitude: -77.1145 },
    amenities: [
      'Air Conditioning',
      'Alcoholic Beverages',
      'Food & Drinks',
      'Non-Smoking',
      'Television',
      'Newspapers & Magazines',
    ],
    accessInstructions:
      'Airside – proceed past security and follow signs to the International Pier.',
    fastTrackAvailable: false,
    fastTrackCount: 0,
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800',
    hours: '7 hours daily',
  },
  {
    id: '3',
    name: 'Copper Bar',
    airport: 'Lima Jorge Chavez Intl',
    terminal: 'International Pier',
    rating: 3,
    reviewCount: 5,
    isOpen: true,
    isNew: true,
    coordinates: { latitude: -12.0221, longitude: -77.1147 },
    amenities: [
      'Air Conditioning',
      'Alcoholic Beverages',
      'Food & Drinks',
      'Non-Smoking',
    ],
    accessInstructions: 'Airside – located on the main terminal floor near Gate 5.',
    fastTrackAvailable: false,
    fastTrackCount: 0,
    image: 'https://images.unsplash.com/photo-1470337458703-46ad1756a187?w=800',
    hours: '8 hours daily',
  },
];

export const featureTiles = [
  { id: '1', label: 'Airport Services', icon: 'airplane', image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=400' },
  { id: '2', label: 'Merchant Offers', icon: 'pricetag', image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=400' },
  { id: '3', label: 'ATM Finder', icon: 'cash', image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400' },
  { id: '4', label: 'Travel Guides', icon: 'map', image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=400' },
  { id: '5', label: 'Account Access', icon: 'person-circle', image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400' },
  { id: '6', label: 'Map View', icon: 'globe', image: 'https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400' },
  { id: '7', label: 'Currency Converter', icon: 'swap-horizontal', image: 'https://images.unsplash.com/photo-1580519542036-c47de6196ba5?w=400' },
  { id: '8', label: 'Tip Calculator', icon: 'calculator', image: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=400' },
  { id: '9', label: 'Card Assistance', icon: 'card', image: 'https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=400' },
  { id: '10', label: 'Benefits', icon: 'gift', image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=400' },
];
