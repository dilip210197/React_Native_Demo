import React from 'react';
import {
  View,
  Text,
  ScrollView,
  FlatList,
  StyleSheet,
  StatusBar,
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../navigation/AppNavigator';
import Header from '../components/Header';
import CategoryCard from '../components/CategoryCard';
import LoungeCard from '../components/LoungeCard';
import { lounges } from '../data/mockData';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'ExploreLounges'>;
  route: RouteProp<RootStackParamList, 'ExploreLounges'>;
};

export default function ExploreLoungesScreen({ navigation }: Props) {
  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor="#002868" />
      <Header
        onBack={() => navigation.goBack()}
        backLabel="HOME"
        showSearch
        onSearch={() => {}}
      />

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Title */}
        <View style={styles.titleBlock}>
          <Text style={styles.title}>Lounges</Text>
          <Text style={styles.location}>Lima, Peru</Text>
        </View>

        {/* Category Section */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>EXPLORE AIRPORT LOUNGE BENEFITS</Text>
        </View>
        <View style={styles.categoryRow}>
          <CategoryCard
            title="DINING"
            subtitle="Browse all lounges with dining options"
            image="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600"
            onPress={() => {}}
          />
          <CategoryCard
            title="SPA"
            subtitle="Browse all lounges with spa facilities"
            image="https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=600"
            onPress={() => {}}
          />
        </View>

        {/* Lounge List Section */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>EXPLORE AIRPORT LOUNGES NEAR YOU</Text>
        </View>

        {lounges.map((lounge) => (
          <LoungeCard
            key={lounge.id}
            lounge={lounge}
            onPress={() => navigation.navigate('LoungeDetail', { lounge })}
          />
        ))}

        <View style={{ height: 30 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#F0F4F8',
  },
  titleBlock: {
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 26,
    fontWeight: '800',
    color: '#002868',
  },
  location: {
    fontSize: 13,
    color: '#666',
    marginTop: 2,
  },
  sectionHeader: {
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 10,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '800',
    color: '#002868',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  categoryRow: {
    flexDirection: 'row',
    paddingHorizontal: 12,
  },
});
