import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
  Linking,
  Alert,
  StatusBar,
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../navigation/AppNavigator';
import Header from '../components/Header';
import AmenityItem from '../components/AmenityItem';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'LoungeDetail'>;
  route: RouteProp<RootStackParamList, 'LoungeDetail'>;
};

function StarRating({ rating }: { rating: number }) {
  return (
    <View style={{ flexDirection: 'row' }}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Ionicons
          key={i}
          name={i <= rating ? 'star' : 'star-outline'}
          size={16}
          color="#BFA046"
        />
      ))}
    </View>
  );
}

export default function LoungeDetailScreen({ navigation, route }: Props) {
  const { lounge } = route.params;
  const [additionalInfoExpanded, setAdditionalInfoExpanded] = useState(false);

  const openDirections = () => {
    const url = `maps://app?daddr=${lounge.coordinates.latitude},${lounge.coordinates.longitude}`;
    Linking.openURL(url).catch(() =>
      Linking.openURL(
        `https://maps.google.com/?q=${lounge.coordinates.latitude},${lounge.coordinates.longitude}`
      )
    );
  };

  const actionButtons = [
    { icon: 'heart-outline', label: 'Favourite' },
    { icon: 'star-outline', label: 'Rate' },
    { icon: 'share-social-outline', label: 'Share' },
    { icon: 'map-outline', label: 'Map' },
    { icon: 'list-outline', label: 'Amenities' },
  ];

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor="#002868" />
      <Header
        onBack={() => navigation.goBack()}
        backLabel="BACK"
        showShare
        onShare={() => Alert.alert('Share', 'Share functionality coming soon.')}
      />

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Title Block */}
        <View style={styles.titleBlock}>
          <Text style={styles.name}>{lounge.name}</Text>
          <View style={styles.ratingRow}>
            <StarRating rating={lounge.rating} />
            <Text style={styles.reviewCount}>
              {lounge.reviewCount} rating{lounge.reviewCount !== 1 ? 's' : ''}
            </Text>
            {lounge.isOpen && (
              <View style={styles.openBadge}>
                <Text style={styles.openText}>OPEN NOW</Text>
              </View>
            )}
          </View>
        </View>

        {/* Hero Image */}
        <Image source={{ uri: lounge.image }} style={styles.heroImage} resizeMode="cover" />

        {/* Action Buttons */}
        <View style={styles.actionRow}>
          {actionButtons.map((btn) => (
            <TouchableOpacity key={btn.label} style={styles.actionBtn} onPress={() => {}}>
              <Ionicons name={btn.icon as any} size={22} color="#002868" />
              <Text style={styles.actionLabel}>{btn.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Location */}
        <View style={styles.section}>
          <View style={styles.locationRow}>
            <View style={styles.locationInfo}>
              <Ionicons name="location-outline" size={18} color="#002868" />
              <View style={styles.locationText}>
                <Text style={styles.locationName}>{lounge.airport}</Text>
                <Text style={styles.locationTerminal}>{lounge.terminal}</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.directionsBtn} onPress={openDirections}>
              <Text style={styles.directionsBtnText}>GET DIRECTIONS</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.accessText}>{lounge.accessInstructions}</Text>
        </View>

        {/* Map */}
        <View style={styles.mapContainer}>
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: lounge.coordinates.latitude,
              longitude: lounge.coordinates.longitude,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01,
            }}
          >
            <Marker
              coordinate={lounge.coordinates}
              title={lounge.name}
              description={lounge.airport}
            />
          </MapView>
        </View>

        {/* Fast Track */}
        {lounge.fastTrackAvailable && (
          <View style={styles.fastTrackBlock}>
            <View style={styles.fastTrackInfo}>
              <Ionicons name="flash-outline" size={18} color="#002868" />
              <Text style={styles.fastTrackText}>
                Fast Track Available: {lounge.fastTrackCount} Fast Track gates open at this airport.
              </Text>
            </View>
            <TouchableOpacity style={styles.fastTrackBtn}>
              <Text style={styles.fastTrackBtnText}>BOOK YOUR FAST TRACK LANE TODAY!</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Additional Information */}
        <View style={styles.section}>
          <TouchableOpacity
            style={styles.additionalHeader}
            onPress={() => setAdditionalInfoExpanded(!additionalInfoExpanded)}
          >
            <Text style={styles.additionalTitle}>ADDITIONAL INFORMATION</Text>
            <Ionicons
              name={additionalInfoExpanded ? 'chevron-up' : 'chevron-down'}
              size={18}
              color="#002868"
            />
          </TouchableOpacity>
          {additionalInfoExpanded && (
            <View style={styles.additionalContent}>
              <View style={styles.infoRow}>
                <Ionicons name="time-outline" size={16} color="#555" />
                <Text style={styles.infoText}>{lounge.hours}</Text>
              </View>
              <Text style={styles.infoNote}>Digital newspapers/magazines available only.</Text>
            </View>
          )}
        </View>

        {/* Amenities */}
        <View style={styles.section}>
          <Text style={styles.amenitiesTitle}>AMENITIES</Text>
          <View style={styles.amenitiesGrid}>
            {lounge.amenities.map((amenity) => (
              <AmenityItem key={amenity} name={amenity} />
            ))}
          </View>
        </View>

        {/* Member Fee */}
        <View style={styles.memberFeeBlock}>
          <Ionicons name="information-circle-outline" size={16} color="#555" />
          <Text style={styles.memberFeeText}>
            Member Fee: Please contact your Diners Club card issuer and issuer regarding your club features and benefits, including membership.
          </Text>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#F0F4F8',
  },
  titleBlock: {
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  name: {
    fontSize: 22,
    fontWeight: '800',
    color: '#002868',
    marginBottom: 8,
    lineHeight: 28,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
  },
  reviewCount: {
    fontSize: 12,
    color: '#777',
  },
  openBadge: {
    backgroundColor: '#2E7D32',
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  openText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '700',
  },
  heroImage: {
    width: '100%',
    height: 200,
  },
  actionRow: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  actionBtn: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionLabel: {
    fontSize: 9,
    color: '#002868',
    fontWeight: '600',
    marginTop: 3,
  },
  section: {
    backgroundColor: '#fff',
    marginTop: 10,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  locationInfo: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    flex: 1,
    marginRight: 10,
  },
  locationText: {
    marginLeft: 6,
    flex: 1,
  },
  locationName: {
    fontSize: 13,
    fontWeight: '700',
    color: '#002868',
  },
  locationTerminal: {
    fontSize: 12,
    color: '#666',
    marginTop: 1,
  },
  directionsBtn: {
    backgroundColor: '#002868',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 5,
  },
  directionsBtnText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  accessText: {
    fontSize: 12,
    color: '#444',
    lineHeight: 18,
  },
  mapContainer: {
    marginTop: 10,
    height: 200,
    overflow: 'hidden',
  },
  map: {
    flex: 1,
  },
  fastTrackBlock: {
    backgroundColor: '#EEF4FF',
    marginTop: 10,
    padding: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#002868',
  },
  fastTrackInfo: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  fastTrackText: {
    fontSize: 12,
    color: '#333',
    marginLeft: 8,
    flex: 1,
    lineHeight: 18,
  },
  fastTrackBtn: {
    backgroundColor: '#002868',
    borderRadius: 5,
    paddingVertical: 10,
    alignItems: 'center',
  },
  fastTrackBtnText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  additionalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  additionalTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: '#002868',
    letterSpacing: 0.5,
  },
  additionalContent: {
    marginTop: 12,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  infoText: {
    fontSize: 12,
    color: '#444',
    marginLeft: 8,
  },
  infoNote: {
    fontSize: 11,
    color: '#666',
    fontStyle: 'italic',
    marginTop: 4,
  },
  amenitiesTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: '#002868',
    letterSpacing: 0.5,
    marginBottom: 12,
  },
  amenitiesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  memberFeeBlock: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#fff',
    marginTop: 10,
    padding: 16,
  },
  memberFeeText: {
    fontSize: 11,
    color: '#666',
    marginLeft: 8,
    flex: 1,
    lineHeight: 16,
    fontStyle: 'italic',
  },
});
