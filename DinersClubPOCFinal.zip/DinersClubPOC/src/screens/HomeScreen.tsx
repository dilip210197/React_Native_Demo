import React from 'react';
import {
  View,
  Text,
  ScrollView,
  FlatList,
  ImageBackground,
  TouchableOpacity,
  StyleSheet,
  Alert,
  StatusBar,
} from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import FeatureTile from '../components/FeatureTile';
import { featureTiles } from '../data/mockData';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'Home'>;
};

export default function HomeScreen({ navigation }: Props) {
  const handleTilePress = (label: string) => {
    if (label === 'Airport Services') {
      // Navigate to airport services if needed
      Alert.alert(label, 'This feature is coming soon.');
    } else {
      Alert.alert(label, 'This feature is coming soon.');
    }
  };

  const renderTile = ({ item }: { item: typeof featureTiles[0] }) => (
    <FeatureTile
      label={item.label}
      icon={item.icon}
      image={item.image}
      onPress={() => handleTilePress(item.label)}
    />
  );

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor="#002868" />

      {/* Top Header */}
      <View style={styles.header}>
        <View style={styles.logo}>
          <Text style={styles.logoText}>D</Text>
        </View>
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Welcome Block */}
        <View style={styles.welcomeBlock}>
          <Text style={styles.welcomeText}>Welcome,{'\n'}Clubmember</Text>
        </View>

        {/* Explore Lounges Hero Card */}
        <TouchableOpacity
          style={styles.heroCard}
          onPress={() => navigation.navigate('ExploreLounges')}
          activeOpacity={0.9}
        >
          <ImageBackground
            source={{ uri: 'https://images.unsplash.com/photo-1559329007-40df8a9345d8?w=800' }}
            style={styles.heroImage}
            imageStyle={{ borderRadius: 10 }}
          >
            <View style={styles.heroOverlay}>
              <Text style={styles.heroLabel}>Explore Lounges</Text>
            </View>
          </ImageBackground>
        </TouchableOpacity>

        {/* Feature Grid */}
        <FlatList
          data={featureTiles}
          renderItem={renderTile}
          keyExtractor={(item) => item.id}
          numColumns={2}
          scrollEnabled={false}
          contentContainerStyle={styles.grid}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#F0F4F8',
  },
  header: {
    backgroundColor: '#002868',
    alignItems: 'center',
    paddingTop: 50,
    paddingBottom: 14,
  },
  logo: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#BFA046',
  },
  logoText: {
    color: '#002868',
    fontSize: 22,
    fontWeight: '900',
    fontStyle: 'italic',
  },
  scroll: {
    flex: 1,
  },
  welcomeBlock: {
    backgroundColor: '#002868',
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  welcomeText: {
    color: '#fff',
    fontSize: 28,
    fontWeight: '800',
    lineHeight: 36,
  },
  heroCard: {
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 8,
    borderRadius: 10,
    overflow: 'hidden',
    height: 140,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 5,
  },
  heroImage: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  heroOverlay: {
    backgroundColor: 'rgba(0,20,80,0.5)',
    padding: 14,
  },
  heroLabel: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  grid: {
    paddingHorizontal: 12,
    paddingBottom: 24,
    paddingTop: 8,
  },
});
