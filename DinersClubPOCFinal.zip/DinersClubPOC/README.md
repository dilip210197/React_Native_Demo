# Diners Club POC — React Native

A proof-of-concept React Native app built with Expo, implementing three core screens from the Diners Club mobile experience: Home, Explore Lounges, and Lounge Detail.

---

## Screens

| Screen | Description |
|---|---|
| **Home** | Welcome screen with a hero "Explore Lounges" card and a 2-column grid of 10 feature tiles |
| **Explore Lounges** | Lounge discovery screen with DINING/SPA category cards and a scrollable lounge list |
| **Lounge Detail** | Full lounge profile with map, amenities grid, fast track booking, and access instructions |

---

## Tech Stack

| Library | Version | Purpose |
|---|---|---|
| Expo | ~55.0.8 | Build toolchain & dev server |
| React Native | 0.83.2 | Core framework |
| React Navigation (Native Stack) | ^7.x | Screen navigation |
| react-native-maps | ^1.27.2 | Embedded map on lounge detail |
| @expo/vector-icons | ^15.1.1 | Ionicons for UI icons |
| react-native-gesture-handler | ^2.30.0 | Navigation gesture support |
| react-native-reanimated | ^4.2.3 | Animation support |
| react-native-safe-area-context | ^5.7.0 | Safe area insets |
| react-native-screens | ^4.24.0 | Native screen optimization |
| TypeScript | ~5.9.2 | Type safety |

---

## Project Structure

```
DinersClubPOC/
├── App.tsx                         # Entry point
├── app.json                        # Expo config (maps API key here)
├── src/
│   ├── navigation/
│   │   └── AppNavigator.tsx        # Stack navigator — wires all 3 screens
│   ├── screens/
│   │   ├── HomeScreen.tsx          # Welcome + feature tile grid
│   │   ├── ExploreLoungesScreen.tsx# Lounge list + category cards
│   │   └── LoungeDetailScreen.tsx  # Full lounge detail + map + amenities
│   ├── components/
│   │   ├── Header.tsx              # Shared top nav bar (back, logo, actions)
│   │   ├── FeatureTile.tsx         # Image background tile for feature grid
│   │   ├── CategoryCard.tsx        # DINING / SPA banner cards
│   │   ├── LoungeCard.tsx          # Lounge list item (image, rating, badges)
│   │   └── AmenityItem.tsx         # Icon + label for amenities grid
│   └── data/
│       └── mockData.ts             # Static mock data for lounges and feature tiles
└── screens/                        # Design reference images (JPEG)
    ├── Home.jpeg
    ├── Explore Lounge screen.jpeg
    └── Lounge detail screen.jpeg
```

---